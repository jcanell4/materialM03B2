/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.m03.uf2.classesibiblioteques.A501;
/**
 *
 * @author Josep Cañellas <jcanell4@ioc.cat>
 */
public class Strings {
    /**
     * Genera i retorna una nova cadena a partir de la cadena passada al primer 
     * paràmetre i el caracter de farciment del segon paràmetre. En cas que la 
     * cadena tingui una mida menor al valor absolut del tercer paràmetre, es genera 
     * una nova cadena concatenant tants caracters de farciment com sigui 
     * necessàri. Si el tercer paràmetre és un valor positiu es farcirà la 
     * cadena per la dreta. Si és un valor negatiu es farcira per l'esquerra.
     * @param cadena és la cadena base per la que es comença la cadena nova.
     * @param farciment és el caràcter de farciment per omplir la nova cadena 
     * fins adquiri la mida demanada
     * @param mida és la mida de la que es disitja la nova cadena.
     * @return la nova cadena generada
     */
    public static String farcirFinsMida(String cadena, char farciment, int mida){
        int midaActual = cadena.length();
        boolean esquerra = mida < 0;
        
        mida = Math.abs(mida);
        
        while(midaActual<mida){
            if(esquerra){
                cadena = farciment + cadena;
            }else{
                cadena += farciment;
            }
            midaActual++;
        }
        return cadena;
    }      

    /**
     * Retorna una cadena generada a partir de la cadena passada en el primer 
     * paràmetre. En cas que la cadena superi la mida del valor del segon 
     * paràmetre, aquesta es retallarà de manera que en concatenar-hi pres punts 
     * esdevingui una cadena de la mida exacta indicada en el segon paràmetre.
     * @param cadena és la cadena base per la que es retallarà si cal.
     * @param mida és la mida de la que es disitja la nova cadena.
     * @return la nova cadena generada
     */
    public static String retallarFinsMida(String cadena, int mida){
        int midaActual = cadena.length();
        
        if(midaActual>mida){
            cadena = cadena.substring(0, mida-3);
            cadena += "...";
        }
        return cadena;
    }      

    /**
     * Retorna una cadena generada a partir de la cadena passada en el primer 
     * paràmetre. En cas que la cadena superi la mida del valor del tercer
     * paràmetre (mida), aquesta es retallarà de manera que en concatenar-hi 
     * tres punts esdevingui una cadena de la mida exacta indicada per mida.
     * En cas que la cadena tingui una mida menor al valor de mida, es genera 
     * una nova cadena concatenant tants caracters de farciment com sigui 
     * necessàri.
     * @param cadena és la cadena base per la que es retallarà si cal.
     * @param mida és la mida de la que es disitja la nova cadena.
     * @return la nova cadena generada
     */
    public static String midaExacta(String cadena, char farciment, int mida){
        int midaActual = cadena.length();
        int midaAbs = Math.abs(mida);
        
        if(midaActual>Math.abs(midaAbs)){
            cadena = retallarFinsMida(cadena, midaAbs);
        }else{
            cadena = farcirFinsMida(cadena, farciment, mida);
        }
        return cadena;
    }      
}
