/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.m03.uf2.classesibiblioteques.A501;

/**
 *
 * @author josep
 */
public class Tasca2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tasca2 prg = new Tasca2();
        
        prg.prova();
    }

    private void prova() {
        String retorn;
        retorn = Strings.retallarFinsMida("Mira com es retalla aquesta frase tan llarga", 12);
        System.out.println("Strings.retallarFinsMida(\"Mira com es retalla aquesta frase tan llarga\", 12) = " + retorn);
        System.out.println(retorn.length()>12?"Error":"Correcte");
        System.out.println("");

        retorn = Strings.retallarFinsMida("Cadena original", 20);
        System.out.println("Strings.retallarFinsMida(\"Cadena original\", 20) = " + retorn);
        System.out.println(retorn.length()>20?"Error":"Correcte");
        System.out.println("");
        
        retorn = Strings.farcirFinsMida("Cargol", '-', 35);
        System.out.println("Strings.farcirFinsMida(\"Cargol\", '-', 35) = " + retorn);
        System.out.println(retorn.length()<35?"Error":"Correcte");
        System.out.println("");

        retorn = Strings.farcirFinsMida("25", '0', -6);
        System.out.println("Strings.farcirFinsMida(\"25\", '0', -6) = " + retorn);
        System.out.println(retorn.length()<6?"Error":"Correcte");
        System.out.println("");
        
        retorn = Strings.farcirFinsMida("78025", '0', -4);
        System.out.println("Strings.farcirFinsMida(\"78025\", '0', -4) = " + retorn);
        System.out.println(retorn.length()<4?"Error":"Correcte");
        System.out.println("");
        
        retorn = Strings.farcirFinsMida("Igual", '0', -4);
        System.out.println("Strings.farcirFinsMida(\"Igual\", '0', 4) = " + retorn);
        System.out.println(retorn.length()<4?"Error":"Correcte");
        System.out.println("");

        retorn = Strings.midaExacta("Frase de prova", '.', 14);
        System.out.println("Strings.midaExacta(\"Frase de prova\", '.', 14) = " + retorn);
        System.out.println(retorn.length()!=14?"Error":"Correcte");
        System.out.println("");
        
        retorn = Strings.midaExacta("Frase de prova", '_', 20);
        System.out.println("Strings.midaExacta(\"Frase de prova\", '_', 20) = " + retorn);
        System.out.println(retorn.length()!=20?"Error":"Correcte");
        System.out.println("");
        
        retorn = Strings.midaExacta("Frase de prova", '_', -20);
        System.out.println("Strings.midaExacta(\"Frase de prova\", '_', -20) = " + retorn);
        System.out.println(retorn.length()!=20?"Error":"Correcte");
        System.out.println("");
        
        retorn = Strings.midaExacta("Frase de prova", '_', 5);
        System.out.println("Strings.midaExacta(\"Frase de prova\", '_', 5) = " + retorn);                
        System.out.println(retorn.length()!=5?"Error":"Correcte");
        System.out.println("");

        retorn = Strings.midaExacta("Frase de prova", '_', -5);
        System.out.println("Strings.midaExacta(\"Frase de prova\", '_', -5) = " + retorn);                
        System.out.println(retorn.length()!=5?"Error":"Correcte");
        System.out.println("");
    }
    
}
